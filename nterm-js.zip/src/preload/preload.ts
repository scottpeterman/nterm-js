// preload.ts — Secure IPC bridge (window.nterm API)
// Exposes typed methods to renderer; all comms go through ipcRenderer.
// No Node.js APIs leak to the renderer.

import { contextBridge, ipcRenderer } from 'electron';

contextBridge.exposeInMainWorld('nterm', {
    // ─── SSH ─────────────────────────────────────────────────
    connect: (sessionId: string, config: any) =>
        ipcRenderer.invoke('ssh:connect', { sessionId, config }),

    disconnect: (sessionId: string) =>
        ipcRenderer.invoke('ssh:disconnect', { sessionId }),

    send: (sessionId: string, data: string) =>
        ipcRenderer.send('ssh:input', { sessionId, data }),

    resize: (sessionId: string, cols: number, rows: number) =>
        ipcRenderer.send('ssh:resize', { sessionId, cols, rows }),

    retryLegacy: (sessionId: string) =>
        ipcRenderer.invoke('ssh:retry-legacy', { sessionId }),

    diagnostics: (sessionId: string) =>
        ipcRenderer.invoke('ssh:diagnostics', { sessionId }),

    listSessions: () =>
        ipcRenderer.invoke('ssh:list-sessions'),

    // ─── SSH Messages (from SSHManager → renderer) ──────────
    onMessage: (callback: (message: any) => void) => {
        ipcRenderer.on('ssh:message', (_event, message) => callback(message));
    },

    // ─── Serial ──────────────────────────────────────────────
    listSerialPorts: (showAll: boolean = false) =>
        ipcRenderer.invoke('serial:list-ports', { showAll }),

    serialSendBreak: (sessionId: string, burst: boolean = false) =>
        ipcRenderer.invoke('serial:send-break', { sessionId, burst }),

    // ─── Sessions ────────────────────────────────────────────
    loadSessionsFile: () =>
        ipcRenderer.invoke('sessions:load-file'),

    loadLastSessionsFile: () =>
        ipcRenderer.invoke('sessions:load-last'),

    saveSessions: (sessions: any) =>
        ipcRenderer.invoke('sessions:save', { sessions }),

    saveSessionsAs: (sessions: any) =>
        ipcRenderer.invoke('sessions:save-as', { sessions }),
    // ─── Settings ────────────────────────────────────────────
    getSettings: () =>
        ipcRenderer.invoke('settings:get-all'),

    getSetting: (key: string) =>
        ipcRenderer.invoke('settings:get', { key }),

    setSetting: (key: string, value: any) =>
        ipcRenderer.invoke('settings:set', { key, value }),

    setSettings: (settings: Record<string, any>) =>
        ipcRenderer.invoke('settings:set-multiple', { settings }),

    resetSetting: (key: string) =>
        ipcRenderer.invoke('settings:reset', { key }),

    resetAllSettings: () =>
        ipcRenderer.invoke('settings:reset-all'),

    getSettingsPath: () =>
        ipcRenderer.invoke('settings:path'),

    getSettingDefaults: () =>
        ipcRenderer.invoke('settings:get-defaults'),

    // ─── Dialogs ─────────────────────────────────────────────
    selectKeyFile: () =>
        ipcRenderer.invoke('dialog:select-keyfile'),

    // ─── Session Capture ─────────────────────────────────────
    captureSelectFile: (defaultName: string) =>
        ipcRenderer.invoke('capture:select-file', { defaultName }),

    captureStart: (sessionId: string, filePath: string) =>
        ipcRenderer.invoke('capture:start', { sessionId, filePath }),

    captureWrite: (sessionId: string, data: string) =>
        ipcRenderer.send('capture:write', { sessionId, data }),

    captureStop: (sessionId: string) =>
        ipcRenderer.invoke('capture:stop', { sessionId }),

    // ─── Vault ───────────────────────────────────────────────
    vaultStatus: () =>
        ipcRenderer.invoke('vault:status'),

    vaultInit: (password: string) =>
        ipcRenderer.invoke('vault:init', { password }),

    vaultUnlock: (password: string, remember: boolean = false) =>
        ipcRenderer.invoke('vault:unlock', { password, remember }),

    vaultLock: () =>
        ipcRenderer.invoke('vault:lock'),

    vaultChangePassword: (oldPassword: string, newPassword: string, remember: boolean = false) =>
        ipcRenderer.invoke('vault:change-password', { oldPassword, newPassword, remember }),

    vaultList: () =>
        ipcRenderer.invoke('vault:list'),

    vaultAdd: (credential: any) =>
        ipcRenderer.invoke('vault:add', { credential }),

    vaultUpdate: (name: string, updates: any) =>
        ipcRenderer.invoke('vault:update', { name, updates }),

    vaultRemove: (name: string) =>
        ipcRenderer.invoke('vault:remove', { name }),

    vaultSetDefault: (name: string) =>
        ipcRenderer.invoke('vault:set-default', { name }),

    vaultMatch: (host: string, port: number = 22, tags: string[] = []) =>
        ipcRenderer.invoke('vault:match', { host, port, tags }),

    vaultDbPath: () =>
        ipcRenderer.invoke('vault:db-path'),

    vaultKeychainClear: () =>
        ipcRenderer.invoke('vault:keychain-clear'),

    readKeyFile: () =>
        ipcRenderer.invoke('dialog:read-keyfile'),

    // ─── DevTools ────────────────────────────────────────────
    openDevTools: () =>
        ipcRenderer.invoke('devtools:open'),

    // ─── App Info ────────────────────────────────────────────
    getVersionInfo: () =>
        ipcRenderer.invoke('app:version-info'),

    // ─── Menu Events (from main process menu → renderer) ────
    onShowAbout: (callback: () => void) => {
        ipcRenderer.on('menu:show-about', () => callback());
    },

    onMenuNewConnection: (callback: () => void) => {
        ipcRenderer.on('menu:new-connection', () => callback());
    },

    onMenuLoadSessions: (callback: () => void) => {
        ipcRenderer.on('menu:load-sessions', () => callback());
    },

onMenuCloseTab: (callback: () => void) => {
    ipcRenderer.on('menu:close-tab', () => callback());
},

onMenuCloseAllTabs: (callback: () => void) => {
    ipcRenderer.on('menu:close-all-tabs', () => callback());
},

onMenuTerminalZoomIn: (callback: () => void) => {
    ipcRenderer.on('menu:terminal-zoom-in', () => callback());
},

onMenuTerminalZoomOut: (callback: () => void) => {
    ipcRenderer.on('menu:terminal-zoom-out', () => callback());
},

onMenuTerminalZoomReset: (callback: () => void) => {
    ipcRenderer.on('menu:terminal-zoom-reset', () => callback());
},

onMenuOpenSettings: (callback: () => void) => {
    ipcRenderer.on('menu:open-settings', () => callback());
},
    
    // ─── Capture Events (from main process → renderer) ──────
    onCaptureError: (callback: (message: any) => void) => {
        ipcRenderer.on('capture:error', (_event, message) => callback(message));
    },

    // ─── Vault Events (from main process → renderer) ────────
    onVaultStateChanged: (callback: (state: any) => void) => {
        ipcRenderer.on('vault:state-changed', (_event, state) => callback(state));
    },
});